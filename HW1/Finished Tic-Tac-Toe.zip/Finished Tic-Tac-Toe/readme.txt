The following will compile and execute code provided all files are in the same directory
"javac RunGame.java && java RunGame"

The board looks like this
[ _ _ _ ]
[ _ _ _ ]
[ _ _ _ ]

Here are the indices/coordinates
[ (0,0) (1,0) (2,0) ]
[ (0,1) (1,1) (2,1) ]
[ (0,2) (1,2) (2,2) ]

When you input the coordinates do it this way: 0 1
No comma or parentheses.

If by mistake you type 01 without spaces. It will read it as the first input (01 or 1)
And it will wait for you to type the second input, so just go ahead and do that.. It will handle # outside the coordinates.
